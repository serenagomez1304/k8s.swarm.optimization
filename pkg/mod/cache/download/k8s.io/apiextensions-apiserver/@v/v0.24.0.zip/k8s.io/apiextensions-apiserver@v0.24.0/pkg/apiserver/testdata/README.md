`swagger.json` contains static openapi definitions needed to build models for custom resource types.

It was created by removing all path and non-objectmeta/int-or-string definitions from 
the `api/openapi-spec/swagger.json` in the `k8s.io/kubernetes` module.